#!/bin/sh
redis-cli FLUSHDB
