class WrongRoom(Exception):
    pass
